# wordle_clone

A simple vanilla js clone of Wordle
<br>
Try it out  [here](https://kaushik268mlore.github.io/THE-WORDLE/) !! 
